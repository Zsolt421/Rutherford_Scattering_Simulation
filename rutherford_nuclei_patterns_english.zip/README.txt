Rutherford Scattering - Nuclei Input Patterns

Each input file contains one nucleus per line in the format:
x y Z

x, y: position in meters
Z: atomic number (79 for gold nuclei in these examples)

Recommended simulation area:
Physical width: 1e-9 m
Physical height: 1e-9 m

To use these patterns, place the .txt files in your CLion Run/Debug working directory (often cmake-build-debug), or configure the working directory accordingly.

At the nuclei input filename prompt, enter e.g. 01_heart.
The simulator automatically adds the .txt extension when needed.

In the current simulator, each nucleus is drawn as a white circle with a radius of 5 pixels. Closely spaced circles may overlap.

Included patterns:
01_heart.txt: 70 nuclei
02_star.txt: 50 nuclei
03_checkerboard.txt: 32 nuclei
04_spiral.txt: 80 nuclei
05_smiley.txt: 113 nuclei
06_galaxy.txt: 82 nuclei
07_butterfly.txt: 163 nuclei
08_target.txt: 78 nuclei
09_lightning.txt: 42 nuclei
10_diamond.txt: 41 nuclei
11_wave.txt: 71 nuclei
12_random_cloud.txt: 65 nuclei
